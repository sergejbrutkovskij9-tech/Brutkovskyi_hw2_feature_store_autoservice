# goit-rdb-hw-02

ДЗ 2: схема даних і feature store для ML-сценарію "автосервіс" (прогноз повторного візиту клієнта протягом 90 днів).

Файли:

- `hw2_feature_store_autoservice.ipynb` - notebook з ER-діаграмою, DDL, тестовими даними, AS-OF запитами, нормалізацією і reflection
- `er_diagram.png` - ER-діаграма
- `er_diagram.dbml` - ER-діаграма у вигляді тексту для dbdiagram.io

Запуск: відкрити notebook у Google Colab і виконати Runtime → Run all. PostgreSQL 16 запускається через pgserver.
